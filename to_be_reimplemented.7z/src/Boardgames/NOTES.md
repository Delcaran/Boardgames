# Grid gerarchies

- Grid
  - SquareGrid
    - Checkerboard (a board with checkered colored pattern)
      - CanadianCheckboard (12x12 checkerboard; lower right corner white)
      - InternationalCheckboard (10x10 checkerboard; lower right corner white)
      - Chessboard (8x8 checkerboard; lower right corner white) <--- also used for most checkers
        - ItalianCheckerboard (lower right corner black)
  - HexGrid