Some simple libraries to be used with boardgames, including some examples.
