#include "checker_canada.h"

namespace SquareGridLib {
	CanadianCheckerboard::CanadianCheckerboard()
		: Checkerboard(12, 12)
	{};

	CanadianCheckerboard::~CanadianCheckerboard() {}
}
