#include "checker_international.h"

namespace SquareGridLib {
	InternationalCheckerboard::InternationalCheckerboard()
		: Checkerboard(10, 10)
	{};

	InternationalCheckerboard::~InternationalCheckerboard() {}
}
