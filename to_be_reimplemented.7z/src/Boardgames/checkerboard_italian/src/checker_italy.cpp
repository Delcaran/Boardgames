#include "checker_italy.h"

namespace SquareGridLib {
  ItalianCheckerboard::ItalianCheckerboard() {}

  ItalianCheckerboard::~ItalianCheckerboard() {}
}
