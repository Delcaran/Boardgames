#include "chessboard.h"

namespace SquareGridLib {
	namespace ChessLib {
		Chessboard::Chessboard()
			: Checkerboard(8, 8)
		{};

		Chessboard::~Chessboard() {}
	}
}
