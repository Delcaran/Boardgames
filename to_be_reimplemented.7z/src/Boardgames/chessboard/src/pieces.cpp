#include "pieces.h"

namespace SquareGridLib {
	namespace ChessLib {
		Piece::Piece() {};

		Piece::~Piece() {};
	}
}
