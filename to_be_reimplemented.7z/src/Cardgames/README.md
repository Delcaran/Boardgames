These are some implementation of popular cardgames
