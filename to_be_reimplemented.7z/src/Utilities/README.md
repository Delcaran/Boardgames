Common utilities useful in all kinds of tabletop games, like dices and the concept of "deck" and "hand"
