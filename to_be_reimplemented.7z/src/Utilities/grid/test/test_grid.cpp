#include <iostream>

#include "Grid.h"

int main() {
	std::cout << "Just testing if it compiles..." << std::endl;
	return 0;
}